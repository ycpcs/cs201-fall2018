package edu.ycp.cs201.mandelbrot;

public class Mandelbrot {
	
	// this stub class is only being included so that the following constants are defined
	public static final int HEIGHT = 800;
	public static final int WIDTH = 800;
	public static final int THRESHOLD = 2000;
}
